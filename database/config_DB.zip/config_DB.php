<?php

 //include ("includes/validator.php");
$DBhost = "localhost";
$DBuser = "vpnpengu_vpnadmuuuuuu";
$DBpass = "Pass@word78";
$DBname = "vpnpengu_vpnadmdddd";

$DBcon = new MySQLi($DBhost,$DBuser,$DBpass,$DBname);


if ($DBcon->connect_errno) {
    die("ERROR : -> ".$DBcon->connect_error);
}
?>