<?php
    error_reporting(0);
 		 ob_start();
    session_start();
 
 	header("Content-Type: text/html;charset=UTF-8");


     if($_SERVER['HTTP_HOST']=="localhost"){

		//local  
		  $DBuser = DEFINE ('DB_USER', 'vpnpengu_vpnadmuuuuuu');
		  $DBpass = DEFINE ('DB_PASSWORD', 'Pass@word78');
		  $DBhost = DEFINE ('DB_HOST', 'localhost'); //host name depends on server
		  $DBname = DEFINE ('DB_NAME', 'vpnpengu_vpnadmdddd');
	
	}else{

		  $DBuser = DEFINE ('DB_USER', 'vpnpengu_vpnadmuuuuuu');
		  $DBpass = DEFINE ('DB_PASSWORD', 'Pass@word78');
		  $DBhost = DEFINE ('DB_HOST', 'localhost'); //host name depends on server
		  $DBname = DEFINE ('DB_NAME', 'vpnpengu_vpnadmdddd');

	}


$DBcon = new MySQLi($DBhost,$DBuser,$DBpass,$DBname);


	$mysqli =mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

	if ($mysqli->connect_errno) {
    	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	}

	mysqli_query($mysqli,"SET NAMES 'utf8'");

    if(isset($_SESSION['id'])){
    	$profile_qry="SELECT * FROM tbl_admin where id='".$_SESSION['id']."'";
	    $profile_result=mysqli_query($mysqli,$profile_qry);
	    $profile_details=mysqli_fetch_assoc($profile_result);

	    define("PROFILE_IMG",$profile_details['image']);
    }
    
	$license_filename="includes/.lic";
    $config_file_default= "dist/function.lic";
	$activate="activate/index.php";
	$install="install/index.php";
	$filename_data="includes/.lic";

?> 
	 
 